from django.apps import AppConfig


class MyalbumapprConfig(AppConfig):
    name = 'myalbumappr'
