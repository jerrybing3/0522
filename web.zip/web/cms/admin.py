from django.contrib import admin
from .models import Restaurant,Food
# Register your models here.


class FoodAdmin(admin.ModelAdmin):
	list_display = ('name', 'price', 'item')

admin.site.register(Food)
admin.site.register(Restaurant)